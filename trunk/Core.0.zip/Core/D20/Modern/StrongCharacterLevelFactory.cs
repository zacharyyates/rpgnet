/* Zachary Yates
 * Copyright � 2007 YatesMorrison Software, LLC.
 * 11/11/2007
 */

namespace YatesMorrison.RolePlay.D20.Modern
{
	//public class StrongCharacterLevelFactory :
	//    CharacterLevelFactory
	//{
	//    protected override BaseCharacterLevel DoCreateLevel(Character character)
	//    {
	//        BaseCharacterLevel level = new BaseCharacterLevel(character, Strings.CLASS_STRONG);
	//        DoAddAttributes(level);
	//        return level;
	//    }

	//    protected override double SkillPointsPerLevel
	//    {
	//        get { return 3; }
	//    }
	//    protected override string HitDie
	//    {
	//        get { return "1d8"; }
	//    }
	//    protected override Progression FortitudeSaveProgression
	//    {
	//        get { return new Progression(1, 2, 2, 2, 3, 3, 4, 4, 4, 5); }
	//    }
	//    protected override Progression ReflexSaveProgression
	//    {
	//        get { return new Progression(0, 0, 1, 1, 1, 2, 2, 2, 3, 3); }
	//    }
	//    protected override Progression WillSaveProgression
	//    {
	//        get { return new Progression(0, 0, 1, 1, 1, 2, 2, 2, 3, 3); }
	//    }
	//    protected override Progression AttackBonusProgression
	//    {
	//        get { return new Progression(1, 2, 3, 4, 5, 6, 7, 8, 9, 10); }
	//    }
	//    protected override Progression DefenseBonusProgression
	//    {
	//        get { return new Progression(1, 2, 2, 3, 3, 3, 4, 4, 5, 5); }
	//    }
	//    protected override Progression ReputationBonusProgression
	//    {
	//        get { return new Progression(0, 0, 0, 0, 1, 1, 1, 1, 2, 2); }
	//    }
	//}
}