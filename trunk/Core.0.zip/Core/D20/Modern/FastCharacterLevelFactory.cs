﻿/* Zachary Yates
 * Copyright © 2007 YatesMorrison Software, LLC.
 * 11/18/2007
 */

namespace YatesMorrison.RolePlay.D20.Modern
{
	//public class FastCharacterLevelFactory : 
	//    CharacterLevelFactory
	//{
	//    protected override Progression AttackBonusProgression
	//    {
	//        get { return new Progression( 0, 1, 2, 3, 3, 4, 5, 6, 6, 7 ); }
	//    }
	//    protected override Progression DefenseBonusProgression
	//    {
	//        get { return new Progression( 3, 4, 4, 5, 5, 6, 6, 7, 7, 8 ); }
	//    }
	//    protected override Progression FortitudeSaveProgression
	//    {
	//        get { return new Progression( 0, 0, 1, 1, 1, 2, 2, 2, 3, 3 ); }
	//    }
	//    protected override Progression ReflexSaveProgression
	//    {
	//        get { return new Progression( 1, 2, 2, 2, 3, 3, 4, 4, 4, 5 ); }
	//    }
	//    protected override Progression WillSaveProgression
	//    {
	//        get { return new Progression( 0, 0, 1, 1, 1, 2, 2, 2, 3, 3 ); }
	//    }
	//    protected override Progression ReputationBonusProgression
	//    {
	//        get { return new Progression( 0, 0, 1, 1, 1, 2, 2, 2, 3, 3 ); }
	//    }

	//    protected override string HitDie
	//    {
	//        get { return "1d8"; }
	//    }

	//    protected override void DoAddSkillPoints(BaseCharacterLevel level)
	//    {
	//        level.SkillPoints = 5 + level.Character.GetEffectedScoreFor(Strings.INT_MOD);
	//    }
	//}
}