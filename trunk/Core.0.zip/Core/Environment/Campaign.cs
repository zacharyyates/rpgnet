using System;
using System.Collections.Generic;
using System.Text;

namespace YatesMorrison.RolePlay
{
	public class Campaign
	{
		public IList<YatesMorrison.RolePlay.Actor> Actors
		{
			get
			{
				throw new System.NotImplementedException();
			}
			set
			{
			}
		}
	}
}
