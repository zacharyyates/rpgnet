﻿/* Zachary Yates
 * Copyright © 2008 YatesMorrison Software, LLC.
 * 02.04.2008
 */

using System;
using System.ServiceModel;

namespace YatesMorrison.RolePlay.BattleFramework
{
	public class ClientRemotePlayerView :
		PlayerView,
		IBattleEvents,
		IDisposable
	{
		BattleSubscriptionServiceProxy m_Proxy;

		public ClientRemotePlayerView()
		{
			InstanceContext context = new InstanceContext(this);
			m_Proxy = new BattleSubscriptionServiceProxy(context);
		}

		public void Subscribe()
		{
			m_Proxy.Subscribe(null);
		}
		public void Unsubscribe()
		{
			m_Proxy.Unsubscribe(null);
		}

		public void OnActorMoved( string actorId, ObjectPosition toPosition )
		{
			IWorldActor actor = m_RealWorld.GetActorBy(actorId);
			actor.Position = toPosition;
		}

		#region IDisposable Implementation	
		protected override void Dispose( bool disposing )
		{
			base.Dispose(disposing);

			if( disposing )
			{
				// free managed resources
				if( m_Proxy != null )
				{
					m_Proxy.Close();
					m_Proxy = null;
				}
			}
		}
		#endregion
	}
}