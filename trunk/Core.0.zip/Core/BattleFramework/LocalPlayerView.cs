﻿/* Zachary Yates
 * Copyright © 2008 YatesMorrison Software, LLC.
 * 02.04.2008
 */

namespace YatesMorrison.RolePlay.BattleFramework
{
	public class LocalPlayerView : PlayerView, IBattleEvents
	{
		public void OnActorMoved( string actorId, ObjectPosition toPosition )
		{
			throw new System.NotImplementedException();
		}

		public override void Subscribe()
		{
			throw new System.NotImplementedException();
		}

		public override void Unsubscribe()
		{
			throw new System.NotImplementedException();
		}
	}
}