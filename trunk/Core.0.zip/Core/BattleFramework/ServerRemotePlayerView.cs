﻿/* Zachary Yates
 * Copyright © 2008 YatesMorrison Software, LLC.
 * 02.04.2008
 */

namespace YatesMorrison.RolePlay.BattleFramework
{
	public class ServerRemotePlayerView : IView, IBattleEvents
	{

		#region IView Members

		public void Subscribe()
		{
			
		}

		public void Unsubscribe()
		{
			throw new System.NotImplementedException();
		}

		public World World
		{
			get { throw new System.NotImplementedException(); }
		}

		#endregion

		#region IBattleEvents Members

		public void OnActorMoved( string actorId, ObjectPosition toPosition )
		{
			throw new System.NotImplementedException();
		}

		#endregion
	}
}