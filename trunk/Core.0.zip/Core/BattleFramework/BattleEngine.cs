﻿/* Zachary Yates
 * Copyright © 2008 YatesMorrison Software, LLC.
 * 02.04.2008
 */

using System.Collections.Generic;

namespace YatesMorrison.RolePlay.BattleFramework
{
	public class BattleEngine
	{
		public List<IView> Views
		{
			get { return m_Views; }
			set { m_Views = value; }
		}
		List<IView> m_Views = new List<IView>();

		public void AttachView( IView view )
		{
			m_Views.Add(view);
			view.Subscribe();
		}

		public void DetatchView( IView view )
		{
			view.Unsubscribe();
			m_Views.Remove(view);
		}


	}
}