﻿/* Zachary Yates
 * Copyright © 2008 YatesMorrison Software, LLC.
 * 1/27/2008
 */

namespace YatesMorrison.RolePlay.BattleFramework
{
	public interface IDisplayObject
	{
		
	}
}