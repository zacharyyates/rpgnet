﻿/* Zachary Yates
 * Copyright © 2008 YatesMorrison Software, LLC.
 * 01.31.2008
 */

using System.ServiceModel;

namespace YatesMorrison.RolePlay.BattleFramework
{
	public interface IBattleEvents
	{
		[OperationContract(IsOneWay = true)]
		void OnActorMoved( string actorId, ObjectPosition toPosition );
	}
}