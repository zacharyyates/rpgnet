﻿/* Zachary Yates
 * Copyright © 2008 YatesMorrison Software, LLC.
 * 02.04.2008
 */

using System.ServiceModel;
using ServiceModelEx;

namespace YatesMorrison.RolePlay.BattleFramework
{
	[ServiceBehavior(InstanceContextMode = InstanceContextMode.PerCall)]
	public class BattleEventPublishService : PublishService<IBattleEvents>, IBattleEvents
	{
		public void OnActorMoved( string actorId, ObjectPosition toPosition )
		{
			FireEvent(actorId, toPosition);
		}
	}
}