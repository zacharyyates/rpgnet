﻿/* Zachary Yates
 * Copyright © 2008 YatesMorrison Software, LLC.
 * 02.04.2008
 */

using System.ServiceModel;

namespace YatesMorrison.RolePlay.BattleFramework
{
	[ServiceContract]
	public interface ISubscriptionService
	{
		[OperationContract]
		void Subscribe( string eventOperation );

		[OperationContract]
		void Unsubscribe( string eventOperation );
	}
}