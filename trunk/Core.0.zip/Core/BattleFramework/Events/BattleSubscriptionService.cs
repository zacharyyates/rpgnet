﻿/* Zachary Yates
 * Copyright © 2008 YatesMorrison Software, LLC.
 * 02.04.2008
 */

using System.ServiceModel;
using ServiceModelEx;

namespace YatesMorrison.RolePlay.BattleFramework
{
	[ServiceContract(CallbackContract = typeof(IBattleEvents))]
	public interface IBattleSubscriptionService : ISubscriptionService { }

	public class BattleSubscriptionService : SubscriptionManager<IBattleEvents>, IBattleSubscriptionService { }

	public partial class BattleSubscriptionServiceProxy : DuplexClientBase<IBattleSubscriptionService>, IBattleSubscriptionService
	{
		public BattleSubscriptionServiceProxy( InstanceContext inputInstance )
			: base(inputInstance)
		{ }

		public BattleSubscriptionServiceProxy( InstanceContext inputInstance, string endpointConfigurationName )
			: base(inputInstance, endpointConfigurationName)
		{ }

		public BattleSubscriptionServiceProxy( InstanceContext inputInstance, string endpointConfigurationName, string remoteAddress )
			: base(inputInstance, endpointConfigurationName, remoteAddress)
		{ }

		public BattleSubscriptionServiceProxy( InstanceContext inputInstance, string endpointConfigurationName, EndpointAddress remoteAddress )
			: base(inputInstance, endpointConfigurationName, remoteAddress)
		{ }

		public BattleSubscriptionServiceProxy( InstanceContext inputInstance, Binding binding, EndpointAddress remoteAddress )
			: base(inputInstance, binding, remoteAddress)
		{ }

		public void Subscribe( string eventOperation )
		{
			Channel.Subscribe(eventOperation);
		}
		public void Unsubscribe( string eventOperation )
		{
			Channel.Unsubscribe(eventOperation);
		}
	}
}