﻿/* Zachary Yates
 * Copyright © 2008 YatesMorrison Software, LLC.
 * 02.04.2008
 */

using System;
using System.Collections.Generic;
using System.Reflection;
using System.Diagnostics;

namespace YatesMorrison.RolePlay.BattleFramework
{
	public abstract class LocalSubscriptionManager<T> where T : class
	{
		static Dictionary<string, List<T>> m_TransientStore;

		static LocalSubscriptionManager()
		{
			m_TransientStore = new Dictionary<string, List<T>>();
			string[] methods = GetOperations();
			Action<string> insert = delegate( string methodName )
									{
										m_TransientStore.Add(methodName, new List<T>());
									};
			Array.ForEach(methods, insert);
		}
		
		static string[] GetOperations()
		{
			MethodInfo[] methods = typeof(T).GetMethods(BindingFlags.Public | BindingFlags.FlattenHierarchy | BindingFlags.Instance);
			List<string> operations = new List<string>(methods.Length);

			Action<MethodInfo> add = delegate( MethodInfo method )
									  {
										  Debug.Assert(!operations.Contains(method.Name));
										  operations.Add(method.Name);
									  };
			Array.ForEach(methods, add);
			return operations.ToArray();
		}

		//Transient subscriptions management 
		internal static T[] GetTransientList( string eventOperation )
		{
			lock( typeof(LocalSubscriptionManager<T>) )
			{
				Debug.Assert(m_TransientStore.ContainsKey(eventOperation));
				if( m_TransientStore.ContainsKey(eventOperation) )
				{
					List<T> list = m_TransientStore[eventOperation];
					return list.ToArray();
				}
				return new T[] { };
			}
		}
		static void AddTransient( T subscriber, string eventOperation )
		{
			lock( typeof(LocalSubscriptionManager<T>) )
			{
				List<T> list = m_TransientStore[eventOperation];
				if( list.Contains(subscriber) )
				{
					return;
				}
				list.Add(subscriber);
			}
		}
		static void RemoveTransient( T subscriber, string eventOperation )
		{
			lock( typeof(LocalSubscriptionManager<T>) )
			{
				List<T> list = m_TransientStore[eventOperation];
				list.Remove(subscriber);
			}
		}

		public void Subscribe( T subscriber, string eventOperation )
		{
			lock( typeof(LocalSubscriptionManager<T>) )
			{
				if( String.IsNullOrEmpty(eventOperation) == false )
				{
					AddTransient(subscriber, eventOperation);
				}
				else
				{
					string[] methods = GetOperations();
					Action<string> addTransient = delegate( string methodName )
												  {
													  AddTransient(subscriber, methodName);
												  };
					Array.ForEach(methods, addTransient);
				}
			}
		}
		public void Unsubscribe( T subscriber, string eventOperation )
		{
			lock( typeof(LocalSubscriptionManager<T>) )
			{
				if( String.IsNullOrEmpty(eventOperation) == false )
				{
					RemoveTransient(subscriber, eventOperation);
				}
				else
				{
					string[] methods = GetOperations();
					Action<string> removeTransient = delegate( string methodName )
													 {
														 RemoveTransient(subscriber, methodName);
													 };
					Array.ForEach(methods, removeTransient);
				}
			}
		}
	}
}