/* Zachary Yates
 * Copyright � 2007 YatesMorrison Software, LLC.
 * 11/10/2007
 */

namespace YatesMorrison.RolePlay
{
	public static class RollHelper
	{
		public static double Roll( string function )
		{
			return new Tokenizer().Evaluate(function);
		}
	}
}