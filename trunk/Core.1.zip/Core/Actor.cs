/* Zachary Yates
 * Copyright 2007 YatesMorrison Software, LLC.
 * 11/3/2007
 */

using System;

namespace YatesMorrison.RolePlay
{
	public class Actor
	{
		public string Name
		{
			get { return m_Name; }
			set { m_Name = value; }
		}
		string m_Name = string.Empty;

		public string Description
		{
			get { return m_Description; }
			set { m_Description = value; }
		}
		string m_Description = string.Empty;

		public double Weight
		{
			get { return m_Weight; }
			set { m_Weight = value; }
		}
		double m_Weight = 0;

		public SizeCategory Size
		{
			get { return m_Size; }
			set { m_Size = value; }
		}
		SizeCategory m_Size;
	}
}