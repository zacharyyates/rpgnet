using System;
using System.Collections.Generic;
using System.Text;

namespace YatesMorrison.RolePlay
{
	public class Inventory
	{
		public IList<YatesMorrison.RolePlay.InventorySlot> Slots
		{
			get
			{
				throw new System.NotImplementedException();
			}
			set
			{
			}
		}
	}
}
