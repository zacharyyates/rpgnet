﻿/* Zachary Yates
 * Copyright © 2007 YatesMorrison Software, LLC.
 * 11/23/2007
 */

using System.Collections.Generic;

namespace YatesMorrison.Math.Lexer
{
	public interface IToken
	{
		void FromString(string token);
		IResult<T> Evaluate();
		IList<IToken> Children { get; }
	}
}